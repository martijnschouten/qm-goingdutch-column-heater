procedure CreateConcentricArcsMM;
var
    Board      : IPCB_Board;
    Arc        : IPCB_Arc;
    CurrentR   : Double;
    Step       : Double;
    StartR     : Double;
    EndR       : Double;
begin
    Board := PCBServer.GetCurrentPCBBoard;
    if Board = nil then
    begin
        ShowError('Please open a PCB document first.');
        Exit;
    end;

    // Parameters in Millimeters
    StartR := MmToCoord(16.3);
    EndR   := MmToCoord(23.0);
    Step   := MmToCoord(0.32);

    CurrentR := StartR;

    PCBServer.PreProcess; // Start undo stack

    while CurrentR <= (EndR + 0.001) do // Added small epsilon for float precision
    begin
        Arc := PCBServer.PCBObjectFactory(eArcObject, eNoDimension, eCreate_Default);

        // Coordinates and Geometry
        Arc.XCenter    := MmToCoord(0);
        Arc.YCenter    := MmToCoord(0);
        Arc.Radius     := CurrentR;
        Arc.LineWidth  := MmToCoord(0.16); // Typical track width
        Arc.StartAngle := 0;
        Arc.EndAngle   := 180;
        Arc.Layer      := LayerUtils.LayerToLayerID('Top Layer');

        Board.AddPCBObject(Arc);

        CurrentR := CurrentR + Step;
    end;

    PCBServer.PostProcess; // End undo stack

    // Refresh the workspace
    ResetParameters;
    Board.ViewManager_FullUpdate;
end;
