procedure CreateConcentricArcsMM;
var
    Board            : IPCB_Board;
    Arc              : IPCB_Arc;
    CurrentR         : Double;
    Step             : Double;
    StartR           : Double;
    EndR             : Double;
    OriginX          : Double;
    OriginY          : Double;
    StartAngleStart  : 0.5;
    StopAngleStart   : 180;
    AngleStep        : 0.5;
    CurrentStartAngle : Double;
    CurrentStopAngle : Double;
begin
    Board := PCBServer.GetCurrentPCBBoard;
    if Board = nil then
    begin
        ShowError('Please open a PCB document first.');
        Exit;
    end;

    // Parameters in Millimeters
    StartR := MmsToCoord(36.3);
    EndR   := MmsToCoord(50.0);
    Step   := MmsToCoord(0.32);

    // Get the Relative Origin coordinates from the board
    OriginX := Board.XOrigin;
    OriginY := Board.YOrigin;

    CurrentR := StartR;
    CurrentStartAngle := StartAngleStart;
    CurrentStopAngle := StopAngleStart;


    PCBServer.PreProcess; // Start undo stack

    while CurrentR <= (EndR + 0.001) do // Added small epsilon for float precision
    begin
        Arc := PCBServer.PCBObjectFactory(eArcObject, eNoDimension, eCreate_Default);

        // Coordinates and Geometry
        Arc.XCenter    := OriginX + MmsToCoord(0);
        Arc.YCenter    := OriginY + MmsToCoord(0);
        Arc.Radius     := CurrentR;
        Arc.LineWidth  := MmsToCoord(0.16); // Typical track width
        Arc.StartAngle := CurrentStartAngle;
        Arc.EndAngle   := CurrentStopAngle;
        Arc.Layer      := eTopLayer;

        Board.AddPCBObject(Arc);

        CurrentR := CurrentR + Step;
        CurrentStopAngle := CurrentStopAngle - AngleStep;
        CurrentStartAngle : = CurrentStartAngle + AngleStep;
    end;

    PCBServer.PostProcess; // End undo stack

    // Refresh the workspace
    ResetParameters;
    Board.ViewManager_FullUpdate;
end;
