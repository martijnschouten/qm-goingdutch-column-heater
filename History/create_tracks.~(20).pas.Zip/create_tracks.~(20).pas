procedure CreateConcentricArcsMM;
var
    Board            : IPCB_Board;
    Arc              : IPCB_Arc;
    CurrentR         : Double;
    Step             : Double;
    StartR           : Double;
    EndR             : Double;
    OriginX          : Double;
    OriginY          : Double;
    AngleStep        : Double;
    StartAngleStartTop  : Double;
    StopAngleStartTop   : Double;
    StartAngleStartBottom  : Double;
    StopAngleStartBottom   : Double;
    CurrentStartAngleTop: Double;
    CurrentStopAngleTop : Double;
    CurrentStartAngleBottom: Double;
    CurrentStopAngleBottom : Double;
    TrackWidth : Double;
begin
    Board := PCBServer.GetCurrentPCBBoard;
    if Board = nil then
    begin
        ShowError('Please open a PCB document first.');
        Exit;
    end;

    // Parameters in Millimeters
    StartR := MmsToCoord(36.3);
    EndR   := MmsToCoord(50.0);
    Step   := MmsToCoord(0.32);

    // Get the Relative Origin coordinates from the board
    OriginX := Board.XOrigin;
    OriginY := Board.YOrigin;

    CurrentR := StartR;

    AngleStep := 0.5;

    StartAngleStartTop := 0;
    StopAngleStartTop := 179.5;
    CurrentStartAngleTop := StartAngleStartTop;
    CurrentStopAngleTop := StartAngleStartTop;

    StartAngleStartBottom := 0;
    StopAngleStartBottom := 179.5;
    CurrentStartAngleBottom := StartAngleStartBottom;
    CurrentStopAngleBottom := StartAngleStartBottom;

    TrackWidth := 0.16;

    PCBServer.PreProcess; // Start undo stack

    while CurrentR <= (EndR + 0.001) do // Added small epsilon for float precision
    begin
        ArcTop := PCBServer.PCBObjectFactory(eArcObject, eNoDimension, eCreate_Default);

        // Coordinates and Geometry
        ArcTop.XCenter    := OriginX + MmsToCoord(0);
        ArcTop.YCenter    := OriginY + MmsToCoord(0);
        ArcTop.Radius     := CurrentR;
        ArcTop.LineWidth  := MmsToCoord(0.16); // Typical track width
        ArcTop.StartAngle := CurrentStartAngleTop;
        ArcTop.EndAngle   := CurrentStopAngleTop;
        ArcTop.Layer      := eTopLayer;

        Board.AddPCBObject(ArcTop);

        CurrentStopAngleTop := CurrentStopAngleTop - AngleStep;
        CurrentStartAngleTop : = CurrentStartAngleTop - AngleStep;

        Arc_bottom := PCBServer.PCBObjectFactory(eArcObject, eNoDimension, eCreate_Default);

        // Coordinates and Geometry
        ArcBottom.XCenter    := OriginX + MmsToCoord(0);
        ArcBottom.YCenter    := OriginY + MmsToCoord(0);
        ArcBottom.Radius     := CurrentR;
        ArcBottom.LineWidth  := MmsToCoord(0.16); // Typical track width
        ArcBottom.StartAngle := CurrentStartAnglebottom;
        ArcBottom.EndAngle   := CurrentStopAnglebottom;
        ArcBottom.Layer      := eTopLayer;

        Board.AddPCBObject(ArcBottom);

        CurrentStopAngleBottom := CurrentStopAngleBottom - AngleStep;
        CurrentStartAngleBottom : = CurrentStartAngleBottom - AngleStep;

        CurrentR := CurrentR + Step;
    end;

    PCBServer.PostProcess; // End undo stack

    // Refresh the workspace
    ResetParameters;
    Board.ViewManager_FullUpdate;
end;
